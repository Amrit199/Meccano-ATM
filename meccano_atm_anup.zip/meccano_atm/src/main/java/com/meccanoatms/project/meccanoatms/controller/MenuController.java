package com.meccanoatms.project.meccanoatms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MenuController {

	/*@RequestMapping("/menu")
	public String menu(@RequestHeader("pin") String pin, Model model) throws Exception {
		try {
			if (pin != null && pin.isEmpty()) {
				return "/menu";
			}
			model.addAttribute("message", "Not an authenticated request!!");
			return "/message";
		} catch (Exception e) {
			model.addAttribute("message", "Not an authenticated request!!");
			return "/message";
		}

	}
*/
}
