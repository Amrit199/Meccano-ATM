package com.meccanoatms.project.meccanoatms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class PayBillController {

	@RequestMapping(value = "/paybill", method = RequestMethod.POST)
	public String payBill(@ModelAttribute("amount") String amount, @ModelAttribute("account") String account,
			Model model) {

		model.addAttribute("message", " Successfully paid " + amount + " to account " + account + " !");

		return "/message";
	}

	@RequestMapping("/paybill")
	public String getPayBillPage() {
		return "paybill";
	}

}
