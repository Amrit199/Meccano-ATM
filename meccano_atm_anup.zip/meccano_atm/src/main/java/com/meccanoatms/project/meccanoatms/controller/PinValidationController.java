package com.meccanoatms.project.meccanoatms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.meccanoatms.project.meccanoatms.model.User;
import com.meccanoatms.project.meccanoatms.service.PinValidationService;
import com.meccanoatms.project.meccanoatms.service.UserService;

@Controller
public class PinValidationController {
	
	
	
	@Autowired
	PinValidationService pinValidationService;
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value="/menu",method=RequestMethod.POST)
	public String login(@ModelAttribute("pin") String pin,Model model) {
		
		if(pinValidationService.validatePin(pin)) {
			
			User user =userService.findUserByPin(pin);
			model.addAttribute("firstname", user.getFirstName());
			model.addAttribute("lastname", user.getLastName());
			return "/menu";
		}
		
		model.addAttribute("message", "wrong pin");
		return "/message";
	}

}
