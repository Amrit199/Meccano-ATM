package com.meccanoatms.project.meccanoatms.controller;

import org.dom4j.rule.Mode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.meccanoatms.project.meccanoatms.model.User;
import com.meccanoatms.project.meccanoatms.service.UserService;

@Controller
public class UserRegistrationController {

	@Autowired
	UserService userService;

	@RequestMapping("/login")
	public String registerUser(@RequestParam("firstname") String firstName,
			@RequestParam("lastname") String lastName, @RequestParam("email") String email,
			@RequestParam("password") String password, Model model) {

		try {
		User existingUser = userService.findUserByEmail(email);
		if (existingUser != null) {
			model.addAttribute("message","User already exists with email " + email);
			return "/message";
		}
		}catch(Exception e) {
			model.addAttribute("message","User already exists with email " + email);
			return "/message";
		}
		

		User user = new User();
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setEmail(email);
		user.setPassword(password);
		user.setActive(1);

		userService.saveUser(user);
		model.addAttribute("message", "User registered successfully!");
		return "/message";
	}

}
