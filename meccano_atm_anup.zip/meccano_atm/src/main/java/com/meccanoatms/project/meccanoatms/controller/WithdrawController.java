package com.meccanoatms.project.meccanoatms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class WithdrawController {

	@RequestMapping(value = "/withdraw", method = RequestMethod.POST)
	public String withdraw(@ModelAttribute("amount") String amount, Model model) {

		if(Integer.valueOf(amount)> 30000) {
			model.addAttribute("message", "Withdraw limit is 30000K only!");
			return "/message";
		}
		
		model.addAttribute("message", "Withdraw successful !");
		return "/message";
	}

	@RequestMapping("/withdraw")
	public String getWithdrawPage() {
		return "/withdraw";
	}

}
