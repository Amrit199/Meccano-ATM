package com.meccanoatms.project.meccanoatms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.meccanoatms.project.meccanoatms.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long>{

	@Query("select u from User u where u.password=:pin")
	public User validateUserWithPin(@Param("pin") String pin);
	
	public User findByEmail(String email);
	
}
