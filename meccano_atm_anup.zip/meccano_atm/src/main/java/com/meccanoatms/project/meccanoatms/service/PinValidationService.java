package com.meccanoatms.project.meccanoatms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.meccanoatms.project.meccanoatms.model.User;
import com.meccanoatms.project.meccanoatms.repository.UserRepository;

@Service
public class PinValidationService {

	@Autowired
	UserRepository userRepository;

	public boolean validatePin(String pin) {

		User user = userRepository.validateUserWithPin(pin);
		if (user != null) {
			return true;
		}
		return false;
	}
}
