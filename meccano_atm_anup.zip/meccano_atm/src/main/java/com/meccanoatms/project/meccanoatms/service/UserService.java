package com.meccanoatms.project.meccanoatms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.meccanoatms.project.meccanoatms.model.User;
import com.meccanoatms.project.meccanoatms.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	public void saveUser(User user) {
		userRepository.save(user);
	}
	
	public User findUserByEmail(String email) {
		return userRepository.findByEmail(email);
	}
	
	public User findUserByPin(String pin) {
		return userRepository.validateUserWithPin(pin);
	}

}
